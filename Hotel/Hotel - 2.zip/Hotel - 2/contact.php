<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php require('inc/links.php'); ?>

    <title>AK Hotel - CONTACT</title>

</head>

<body class="bg-light">

    <?php require('inc/header2.php'); ?>

    <div class="my-5 px-4">
        <h2 class="fw-bold h-font text-center">CONTACT US</h2>
        <div class="h-line bg-dark" style="width: 150px; margin: 0 auto; height: 1.7px;"></div>
        <p class="text-center mt-3">
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nesciunt laborum veniam quo omnis iure corrupti
            soluta facilis ipsam eligendi! Perferendis velit <br> sunt minima voluptas molestias incidunt, dicta
            excepturi
            ratione similique!
        </p>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-mg-6 mb-5 px-4">
                <div class="bg-white rounded shadow p-4">

                    <iframe class="w-100 rounded mb-4" height="320px"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d121058.92836558867!2d73.79292689216219!3d18.52476632659678!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bf2e67461101%3A0x828d43bf9d9ee343!2sPune%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1642944026800!5m2!1sen!2sin"
                        loading="lazy"></iframe>

                    <h5>Address</h5>

                    <a target="_blank" class="d-inline-block text-decoration-none text-dark mb-2"
                        href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d121058.92836558867!2d73.79292689216219!3d18.52476632659678!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bf2e67461101%3A0x828d43bf9d9ee343!2sPune%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1642944026800!5m2!1sen!2sin">
                        <i class="bi bi-geo-alt-fill"></i> AK Hotel, Kothrud, Pune
                    </a>

                    <h5 class="mt-4">Contact Us</h5>

                    <a href="tel: +918600359275" class="d-inline-block mb-2 text-decoration-none text-dark">
                        <i class="bi bi-telephone-fill"></i> &nbsp;+91 &nbsp; 8600359275
                    </a>
                    <br>

                    <a href="mailto:adityakarande38@gmail.com"
                        class="d-inline-block mb-2 text-decoration-none text-dark">
                        <i class="bi bi-envelope-fill"></i> &nbsp;adityakarande38@gmail.com
                    </a>

                    <h5 class="mt-4">Follow Us</h5>

                    <a href="#" class="d-inline-block text-dark fs-5 me-2">
                        <i class="bi bi-twitter me-1"></i>
                    </a>

                    <a href="#" class="d-inline-block text-dark fs-5 me-2">
                        <i class="bi bi-facebook me-1"></i>
                    </a>

                    <a href="#" class="d-inline-block text-dark fs-5">
                        <i class="bi bi-instagram me-1"></i>
                    </a>

                </div>
            </div>
            <div class="col-lg-6 col-mg-6 px-4">
                <div class="bg-white rounded shadow p-4">
                    <form action="">
                        <h5>Send a message</h5>
                        <div class="mt-3">
                            <label class="form-label" style="font-weight: 500;">Name</label>
                            <input type="text" class="form-control shadow-none">
                        </div>
                        <div class="mt-3">
                            <label class="form-label" style="font-weight: 500;">Email</label>
                            <input type="email" class="form-control shadow-none">
                        </div>
                        <div class="mt-3">
                            <label class="form-label" style="font-weight: 500;">Subject</label>
                            <input type="text" class="form-control shadow-none">
                        </div>
                        <div class="mt-3">
                            <label class="form-label" style="font-weight: 500;">Message</label>
                            <textarea class="form-control shadow-none" rows="5" style="resize: none;"></textarea>
                        </div>
                        <button type="submit" class="btn text-white custom-bg mt-3">
                            SEND
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc/footer.php'); ?>

</body>

</html>