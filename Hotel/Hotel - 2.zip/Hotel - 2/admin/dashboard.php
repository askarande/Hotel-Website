<?php

    require('inc/essentials.php');
    adminLogin();
    


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Dashboard</title>
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/hotel2.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Merienda:wght@400;700&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

    <?php

        require('inc/links.php');

    ?>

</head>
<body class="bg-light">


    <?php require('inc/header.php') ?>


    <div class="container-fluid" id="main-content">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse excepturi sunt quam aut, culpa officiis
            repellat in, iste quasi assumenda, ipsa dolores. Facilis ea est cumque. Rem delectus praesentium obcaecati!
        </div>
    </div>
</div>



    <?php

        require('inc/script.php');

    ?>
</body>
</html>